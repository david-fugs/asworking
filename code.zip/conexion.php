<?php
	
	$mysqli = new mysqli("localhost", 'softepuc_aswworking', 'q9]sHoKl4SV%zk0', 'softepuc_aswworking');
	$mysqli->set_charset('utf8');
?>
