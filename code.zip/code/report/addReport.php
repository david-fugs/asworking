<?php
session_start();
include("../../conexion.php");
if (!isset($_SESSION['id'])) {
    header("Location: ../../index.php");
}
$nombre = $_SESSION['nombre'];
$tipo_usu = $_SESSION['tipo_usuario'];

if (isset($_GET['delete'])) {
    $num_doc_cta = $_GET['delete'];
    deleteMember($num_doc_cta);
}
function deleteMember($id_store)
{
    global $mysqli; // Asegurar acceso a la conexión global

    $query = "DELETE FROM store WHERE id_store  = ?";
    $stmt = $mysqli->prepare($query);
    $stmt->bind_param("s", $id_store);

    if ($stmt->execute()) {
        echo "<script>alert('sucursal deleted correctly');
        window.location = 'seeSucursal.php';</script>";
    } else {
        echo "<script>alert('Error deleting the sucursal');
        window.location = 'seeSucursal.php';</script>";
    }

    $stmt->close();
}
function getStatus($estado)
{
    if ($estado == 1) {
        return "<span class='badge bg-success'>ACTIVO</span>";
    } else {
        return "<span class='badge bg-danger'>INACTIVO</span>";
    }
}

// Obtener los filtros desde el formulario
$store_name = isset($_GET['store_name']) ? trim($_GET['store_name']) : '';
$code_sucursal = isset($_GET['code_sucursal']) ? trim($_GET['code_sucursal']) : '';

?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>ASWWORKING | SOFT</title>
    <script src="js/64d58efce2.js"></script>
    <link href="https://fonts.googleapis.com/css?family=Lobster" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Orbitron" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="../items/css/styles.css">
    <link rel="stylesheet" type="text/css" href="../items/css/estilos2024.css">
    <link rel="stylesheet" href="../../css/navbar.css">
    <script src="https://kit.fontawesome.com/fed2435e21.js" crossorigin="anonymous"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

</head>

<body>
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl"></script>
    <div class="header-container">
        <div class="header">
            <div class="logo-container">
                <img src='../../img/logo.png' class="logo" alt="Logo">
            </div>
            <h1 class="title"><i class="fa-solid fa-file-signature"></i> DAILY REPORT</h1>
        </div>
    </div>

    <div class="top-bar">
        <div></div>
        <div class="center">
            <a href="../../access.php" class="back-btn" title="Go Back">
                <i class="fas fa-arrow-circle-left fa-xl"></i>
            </a>
        </div>
        <div style="display: flex; justify-content: flex-end; margin: 20px 0;">
            <a href="seeReport.php" class="btn-add-store">
                <i class="fas fa-file-alt"></i> See Daily Report
            </a>
        </div>
    </div>
    <?php
    date_default_timezone_set("America/Bogota");
    include("../../conexion.php");
    require_once("../../zebra.php");
    //traigo las tiendas para el select del modal
    $sql_store = "SELECT * FROM store 
    JOIN sucursal ON store.id_store = sucursal.id_store 
    ORDER BY store_name ASC";
    $result_store = $mysqli->query($sql_store);
    if (!$result_store) {
        die("Error en la consulta: " . $mysqli->error);
    }
    $stores = $result_store->fetch_all(MYSQLI_ASSOC);

    ?>
    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-10 col-lg-8">
                <form action="processReport.php" method="POST" class="form-container">
                    <h5 class="form-title">New Report</h5>
                    <div class="row g-3">
                        <div class="col-md-6 form-group">
                            <label for="upc_asignado_report" class="form-label"> Assigned UPC</label>
                            <input type="text" class="form-control form-control-sm" id="upc_asignado_report" onblur="buscarUPC() " name="upc_asignado_report">
                        </div>

                        <div class="col-md-6 form-group">
                            <label for="upc_final_report" class="form-label"> Final UPC</label>
                            <input type="text" class="form-control form-control-sm" id="upc_final_report" name="upc_final_report">
                        </div>

                        <div class="col-md-6 form-group">
                            <label for="cons_report" class="form-label">Cons</label>
                            <input type="text" class="form-control form-control-sm" id="cons_report" name="cons_report" required>
                        </div>

                        <div class="col-md-6 form-group">
                            <label for="folder_report" class="form-label">Folder</label>
                            <input type="text" class="form-control form-control-sm" id="folder_report" name="folder_report" required>
                        </div>

                        <div class="col-md-6 form-group">
                            <label for="loc_report" class="form-label">Location</label>
                            <input type="text" class="form-control form-control-sm" id="loc_report" name="loc_report">
                        </div>

                        <div class="col-md-6 form-group mt-4">
                            <label for="quantity_report" class="form-label">Quantity</label>
                            <input type="number" class="form-control form-control-sm" id="quantity_report" name="quantity_report" required>
                        </div>

                        <div class="col-md-6 form-group">
                            <label for="sku_report" class="form-label">SKU</label>
                            <input type="text" class="form-control form-control-sm" id="sku_report" name="sku_report">
                        </div>

                        <div class="col-md-6 form-group">
                            <label for="brand_report" class="form-label">Brand</label>
                            <input type="text" class="form-control form-control-sm" id="brand_report" name="brand_report">
                        </div>

                        <div class="col-md-6 form-group">
                            <label for="item_report" class="form-label">Item</label>
                            <input type="text" class="form-control form-control-sm" id="item_report" name="item_report">
                        </div>

                        <div class="col-md-6 form-group">
                            <label for="vendor_report" class="form-label">Vendor </label>
                            <input type="text" class="form-control form-control-sm" id="vendor_report" name="vendor_report">
                        </div>

                        <div class="col-md-6 form-group">
                            <label for="color_report" class="form-label">Color</label>
                            <input type="text" class="form-control form-control-sm" id="color_report" name="color_report">
                        </div>

                        <div class="col-md-6 form-group">
                            <label for="size_report" class="form-label">Size</label>
                            <input type="text" class="form-control form-control-sm" id="size_report" name="size_report">
                        </div>

                        <div class="col-md-6 form-group">
                            <label for="category_report" class="form-label">Category</label>
                            <input type="text" class="form-control form-control-sm" id="category_report" name="category_report">
                        </div>

                        <div class="col-md-6 form-group">
                            <label for="weight_report" class="form-label">Weight</label>
                            <input type="text" step="0.01" class="form-control form-control-sm" id="weight_report" name="weight_report">
                        </div>

                        <div class="col-md-6 form-group">
                            <label for="inventory_report" class="form-label">Inventory</label>
                            <input type="text" class="form-control form-control-sm" id="inventory_report" name="inventory_report">
                        </div>

                        <div class="col-md-6 form-group mt-4">
                            <label for="sucursal_report" class="form-label">Sucursal</label>
                            <select class="form-select form-select-sm" id="sucursal_report" name="sucursal_report" required>
                                <option value="">Select Sucursal</option>
                                <?php foreach ($stores as $store) : ?>
                                    <option value="<?= $store['id_sucursal'] ?>"><?= $store['code_sucursal'] ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <div class="col-12">
                            <label for="observacion_report" class="form-label">Observation</label>
                            <textarea class="form-control form-control-sm" id="observacion_report" name="observacion_report" rows="2"></textarea>
                        </div>
                    </div>
                    <div class=" mt-4 d-flex justify-content-center " style="margin-left: 90px;" >
                        <button type="submit" class="btn-add-store">Send</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <!-- modal opciones -->
    <div class="modal fade" id="modalOpcionesUPC" tabindex="-1" aria-labelledby="modalOpcionesUPCLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Select the correct reference</h5>
                </div>
                <div class="modal-body" id="contenedorOpcionesUPC">
                    <!-- Aquí se insertan las opciones -->
                </div>
            </div>
        </div>
    </div>
    <div class="back">
        <div></div>
        <div class="">
            <a href="../../access.php" class="back-btn" title="Go Back">
                <i class="fas fa-arrow-circle-left fa-xl"></i>
            </a>
        </div>
    </div>

    <script src="https://www.jose-aguilar.com/scripts/fontawesome/js/all.min.js" data-auto-replace-svg="nest"></script>
    <script>
        function buscarUPC() {
            let upc = $('#upc_asignado_report').val();

            if (upc.trim() === "") return;

            $.ajax({
                url: 'buscar_upc_detalle.php',
                type: 'POST',
                dataType: 'json',
                data: {
                    upc: upc
                },
                success: function(data) {
                    if (data.success) {
                        if (data.multiple) {
                            mostrarOpcionesUPC(data.data);
                        } else {
                            llenarFormulario(data.data[0]);
                            alert("✅ UPC Found.");
                        }
                    } else {
                        limpiarCampos();
                        alert("❌ UPC not found.");
                    }
                },
                error: function() {
                    alert("⚠️ Error .");
                }
            });
        }

        function llenarFormulario(item) {
            $('#quantity_report').val(item.quantity_inventory);
            $('#brand_report').val(item.brand_item);
            $('#item_report').val(item.item);
            $('#color_report').val(item.color_item);
            $('#size_report').val(item.size_item);
            $('#category_report').val(item.category_item);
            $('#weight_report').val(item.weight_item);
            $('#inventory_report').val(item.inventory_item);
            $('#sku_report').val(item.sku);
            $('#vendor_report').val(item.ref_item);
        }

        function mostrarOpcionesUPC(opciones) {
            let contenedor = $('#contenedorOpcionesUPC');
            contenedor.empty();

            opciones.forEach((item, index) => {
                contenedor.append(`
        <div class="card mb-2 shadow-sm border-0">
            <div class="card-body p-2">
                <button 
                    class="btn btn-light text-start w-100 border rounded d-flex flex-column align-items-start" 
                    onclick='seleccionarUPC(${JSON.stringify(item)})'
                >
                    <strong class="text-primary">${item.item}</strong>
                    <small class="text-muted">
                        Color: ${item.color_item} | Size ${item.size_item} | Ref: ${item.ref_item}
                    </small>
                </button>
            </div>
        </div>
    `);
            });

            $('#modalOpcionesUPC').modal('show');
        }

        function seleccionarUPC(item) {
            $('#modalOpcionesUPC').modal('hide');
            llenarFormulario(item);
            alert("✅ UPC selected correctly.");
        }

        function limpiarCampos() {
            $('#quantity_report').val('');
            $('#brand_report').val('');
            $('#item_report').val('');
            $('#color_report').val('');
            $('#size_report').val('');
            $('#category_report').val('');
            $('#weight_report').val('');
            $('#inventory_report').val('');
            $('#sku_report').val('');
            $('#vendor_report').val('');
        }
        document.addEventListener("DOMContentLoaded", function() {
            let modalEdicion = document.getElementById("modalEdicion");

            modalEdicion.addEventListener("show.bs.modal", function(event) {
                let button = event.relatedTarget; // Botón que abrió el modal
                document.getElementById("id_store").value = button.getAttribute("data-id_store");
                document.getElementById("edit-name").value = button.getAttribute("data-name");

            });

            // Enviar datos al servidor con AJAX al hacer clic en "Guardar cambios"
            document.getElementById("guardarCambios").addEventListener("click", function() {
                let formData = new FormData(document.getElementById("formEditar"));

                fetch("editItems.php", {
                        method: "POST",
                        body: formData
                    })
                    .then(response => response.json())
                    .then(data => {
                        if (data.success) {
                            alert("Registro actualizado correctamente");
                            window.location.reload(); // Recargar la página para ver los cambios
                        } else {
                            alert("Error al actualizar");
                        }
                    })
                    .catch(error => console.error("Error:", error));
            });
        });
    </script>
</body>

</html>